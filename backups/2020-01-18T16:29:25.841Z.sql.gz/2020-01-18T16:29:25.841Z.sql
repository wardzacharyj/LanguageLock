/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: Tags
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: TermTags
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `TermTags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `termId` int(11) DEFAULT NULL,
  `tagId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_tag_term` (`tagId`, `termId`),
  KEY `termId` (`termId`),
  CONSTRAINT `TermTags_ibfk_1` FOREIGN KEY (`termId`) REFERENCES `Terms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `TermTags_ibfk_2` FOREIGN KEY (`tagId`) REFERENCES `Tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 302 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: Terms
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Terms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastStudied` datetime DEFAULT NULL,
  `side1` varchar(255) DEFAULT NULL,
  `side2` varchar(255) DEFAULT NULL,
  `side3` varchar(255) DEFAULT NULL,
  `translation` varchar(255) DEFAULT NULL,
  `partOfSpeech` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `occurencesStudied` int(10) unsigned DEFAULT '0',
  `durationStudied` int(10) unsigned DEFAULT '0',
  `side1_correct` int(10) unsigned DEFAULT '0',
  `side2_correct` int(10) unsigned DEFAULT '0',
  `side3_correct` int(10) unsigned DEFAULT '0',
  `side1_unknown` int(10) unsigned DEFAULT '0',
  `side2_unknown` int(10) unsigned DEFAULT '0',
  `side3_unknown` int(10) unsigned DEFAULT '0',
  `side1_incorrect` int(10) unsigned DEFAULT '0',
  `side2_incorrect` int(10) unsigned DEFAULT '0',
  `side3_incorrect` int(10) unsigned DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 302 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: UserHistories
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `UserHistories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `timeOfLogin` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `UserHistories_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `Users` (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: Users
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastLogin` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: Tags
# ------------------------------------------------------------

INSERT INTO
  `Tags` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    1,
    'hsk1',
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Tags` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    2,
    'hsk2',
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: TermTags
# ------------------------------------------------------------

INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    1,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    1,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    2,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    2,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    3,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    3,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    4,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    4,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    5,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    5,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    6,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    6,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    7,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    7,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    8,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    8,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    9,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    9,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    10,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    10,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    11,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    11,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    12,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    12,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    13,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    13,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    14,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    14,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    15,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    15,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    16,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    16,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    17,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    17,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    18,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    18,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    19,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    19,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    20,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    20,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    21,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    21,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    22,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    22,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    23,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    23,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    24,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    24,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    25,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    25,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    26,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    26,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    27,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    27,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    28,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    28,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    29,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    29,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    30,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    30,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    31,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    31,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    32,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    32,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    33,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    33,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    34,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    34,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    35,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    35,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    36,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    36,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    37,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    37,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    38,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    38,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    39,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    39,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    40,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    40,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    41,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    41,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    42,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    42,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    43,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    43,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    44,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    44,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    45,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    45,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    46,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    46,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    47,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    47,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    48,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    48,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    49,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    49,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    50,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    50,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    51,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    51,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    52,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    52,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    53,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    53,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    54,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    54,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    55,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    55,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    56,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    56,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    57,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    57,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    58,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    58,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    59,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    59,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    60,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    60,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    61,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    61,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    62,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    62,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    63,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    63,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    64,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    64,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    65,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    65,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    66,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    66,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    67,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    67,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    68,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    68,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    69,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    69,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    70,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    70,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    71,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    71,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    72,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    72,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    73,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    73,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    74,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    74,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    75,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    75,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    76,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    76,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    77,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    77,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    78,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    78,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    79,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    79,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    80,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    80,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    81,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    81,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    82,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    82,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    83,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    83,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    84,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    84,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    85,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    85,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    86,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    86,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    87,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    87,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    88,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    88,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    89,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    89,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    90,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    90,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    91,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    91,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    92,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    92,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    93,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    93,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    94,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    94,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    95,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    95,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    96,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    96,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    97,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    97,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    98,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    98,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    99,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    99,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    100,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    100,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    101,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    101,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    102,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    102,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    103,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    103,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    104,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    104,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    105,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    105,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    106,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    106,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    107,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    107,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    108,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    108,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    109,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    109,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    110,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    110,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    111,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    111,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    112,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    112,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    113,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    113,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    114,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    114,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    115,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    115,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    116,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    116,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    117,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    117,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    118,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    118,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    119,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    119,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    120,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    120,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    121,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    121,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    122,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    122,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    123,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    123,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    124,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    124,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    125,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    125,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    126,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    126,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    127,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    127,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    128,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    128,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    129,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    129,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    130,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    130,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    131,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    131,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    132,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    132,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    133,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    133,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    134,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    134,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    135,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    135,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    136,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    136,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    137,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    137,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    138,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    138,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    139,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    139,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    140,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    140,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    141,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    141,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    142,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    142,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    143,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    143,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    144,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    144,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    145,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    145,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    146,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    146,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    147,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    147,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    148,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    148,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    149,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    149,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    150,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    150,
    1
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    151,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    151,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    152,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    152,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    153,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    153,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    154,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    154,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    155,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    155,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    156,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    156,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    157,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    157,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    158,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    158,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    159,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    159,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    160,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    160,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    161,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    161,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    162,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    162,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    163,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    163,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    164,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    164,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    165,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    165,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    166,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    166,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    167,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    167,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    168,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    168,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    169,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    169,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    170,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    170,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    171,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    171,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    172,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    172,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    173,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    173,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    174,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    174,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    175,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    175,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    176,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    176,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    177,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    177,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    178,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    178,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    179,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    179,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    180,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    180,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    181,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    181,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    182,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    182,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    183,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    183,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    184,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    184,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    185,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    185,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    186,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    186,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    187,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    187,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    188,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    188,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    189,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    189,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    190,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    190,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    191,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    191,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    192,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    192,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    193,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    193,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    194,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    194,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    195,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    195,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    196,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    196,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    197,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    197,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    198,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    198,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    199,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    199,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    200,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    200,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    201,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    201,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    202,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    202,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    203,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    203,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    204,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    204,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    205,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    205,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    206,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    206,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    207,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    207,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    208,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    208,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    209,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    209,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    210,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    210,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    211,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    211,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    212,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    212,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    213,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    213,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    214,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    214,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    215,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    215,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    216,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    216,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    217,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    217,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    218,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    218,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    219,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    219,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    220,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    220,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    221,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    221,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    222,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    222,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    223,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    223,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    224,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    224,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    225,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    225,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    226,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    226,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    227,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    227,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    228,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    228,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    229,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    229,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    230,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    230,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    231,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    231,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    232,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    232,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    233,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    233,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    234,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    234,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    235,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    235,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    236,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    236,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    237,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    237,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    238,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    238,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    239,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    239,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    240,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    240,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    241,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    241,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    242,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    242,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    243,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    243,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    244,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    244,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    245,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    245,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    246,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    246,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    247,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    247,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    248,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    248,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    249,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    249,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    250,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    250,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    251,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    251,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    252,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    252,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    253,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    253,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    254,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    254,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    255,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    255,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    256,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    256,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    257,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    257,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    258,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    258,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    259,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    259,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    260,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    260,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    261,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    261,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    262,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    262,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    263,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    263,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    264,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    264,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    265,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    265,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    266,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    266,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    267,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    267,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    268,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    268,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    269,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    269,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    270,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    270,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    271,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    271,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    272,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    272,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    273,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    273,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    274,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    274,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    275,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    275,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    276,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    276,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    277,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    277,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    278,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    278,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    279,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    279,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    280,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    280,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    281,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    281,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    282,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    282,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    283,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    283,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    284,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    284,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    285,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    285,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    286,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    286,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    287,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    287,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    288,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    288,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    289,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    289,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    290,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    290,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    291,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    291,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    292,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    292,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    293,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    293,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    294,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    294,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    295,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    295,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    296,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    296,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    297,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    297,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    298,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    298,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    299,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    299,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    300,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    300,
    2
  );
INSERT INTO
  `TermTags` (`id`, `createdAt`, `updatedAt`, `termId`, `tagId`)
VALUES
  (
    301,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56',
    301,
    2
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: Terms
# ------------------------------------------------------------

INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    NULL,
    '愛',
    '爱',
    'ài',
    'love',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2,
    NULL,
    '八',
    '八',
    'bā',
    'eight',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    3,
    NULL,
    '爸爸',
    '爸爸',
    'bàba',
    'Dad',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    4,
    NULL,
    '杯子',
    '杯子',
    'bēizi',
    'cup; glass',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    5,
    NULL,
    '北京',
    '北京',
    'Běijīng',
    'Beijing',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    6,
    NULL,
    '本',
    '本',
    'běn',
    'measure word for books',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    7,
    NULL,
    '不客氣',
    '不客气',
    'bú kèqi',
    'you\'re welcome; don\'t be polite',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    8,
    NULL,
    '不',
    '不',
    'bù',
    'no; not',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    9,
    NULL,
    '菜',
    '菜',
    'cài',
    'dish (type of food); vegetables',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    10,
    NULL,
    '茶',
    '茶',
    'chá',
    'tea',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    11,
    NULL,
    '吃',
    '吃',
    'chī',
    'eat',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    12,
    NULL,
    '出租車',
    '出租车',
    'chūzūchē',
    'taxi; cab',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    13,
    NULL,
    '打電話',
    '打电话',
    'dǎ diànhuà',
    'make a phone call',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    14,
    NULL,
    '大',
    '大',
    'dà',
    'big; large',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    15,
    NULL,
    '的',
    '的',
    'de',
    'indicates possession, like adding \'s to a noun',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    16,
    NULL,
    '點',
    '点',
    'diǎn',
    'a dot; a little; o\'clock',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    17,
    NULL,
    '電腦',
    '电脑',
    'diànnǎo',
    'computer',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    18,
    NULL,
    '電視',
    '电视',
    'diànshì',
    'television; TV',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    19,
    NULL,
    '電影',
    '电影',
    'diànyǐng',
    'movie; film',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    20,
    NULL,
    '東西',
    '东西',
    'dōngxi',
    'things; stuff',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    21,
    NULL,
    '都',
    '都',
    'dōu',
    'all; both',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    22,
    NULL,
    '讀',
    '读',
    'dú',
    'to read; to study',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    23,
    NULL,
    '對不起',
    '对不起',
    'duìbuqǐ',
    'sorry',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    24,
    NULL,
    '多',
    '多',
    'duō',
    'many',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    25,
    NULL,
    '多少',
    '多少',
    'duōshao',
    'how much?; how many?',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    26,
    NULL,
    '兒子',
    '儿子',
    'érzi',
    'son',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    27,
    NULL,
    '二',
    '二',
    'èr',
    'two',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    28,
    NULL,
    '飯店',
    '饭店',
    'fàndiàn',
    'restaurant; hotel',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    29,
    NULL,
    '飛機',
    '飞机',
    'fēijī',
    'airplane',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    30,
    NULL,
    '分鐘',
    '分钟',
    'fēnzhōng',
    'minute; (measure word for time)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    31,
    NULL,
    '高興',
    '高兴',
    'gāoxìng',
    'happy; glad',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    32,
    NULL,
    '個',
    '个',
    'ge',
    'general measure word',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    33,
    NULL,
    '工作',
    '工作',
    'gōngzuò',
    'work; a job',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    34,
    NULL,
    '狗',
    '狗',
    'gǒu',
    'dog',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    35,
    NULL,
    '漢語',
    '汉语',
    'Hànyǔ',
    'Chinese language',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    36,
    NULL,
    '好',
    '好',
    'hǎo',
    'good',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    37,
    NULL,
    '號',
    '号',
    'hào',
    'number; day of a month',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    38,
    NULL,
    '喝',
    '喝',
    'hē',
    'to drink',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    39,
    NULL,
    '和',
    '和',
    'hé',
    'and; with',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    40,
    NULL,
    '很',
    '很',
    'hěn',
    'very; quite',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    41,
    NULL,
    '后面',
    '后面',
    'hòumian',
    'back; behind',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    42,
    NULL,
    '回',
    '回',
    'huí',
    'to return; to reply; to go back',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    43,
    NULL,
    '會',
    '会',
    'huì',
    'know how to',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    44,
    NULL,
    '幾',
    '几',
    'jǐ',
    'how many; several; a few',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    45,
    NULL,
    '家',
    '家',
    'jiā',
    'family; home',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    46,
    NULL,
    '叫',
    '叫',
    'jiào',
    'to be called',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    47,
    NULL,
    '今天',
    '今天',
    'jīntiān',
    'today',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    48,
    NULL,
    '九',
    '九',
    'jiǔ',
    'nine',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    49,
    NULL,
    '開',
    '开',
    'kāi',
    'to open; to start; to operate (a vehicle)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    50,
    NULL,
    '看',
    '看',
    'kàn',
    'see; look at; to watch',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    51,
    NULL,
    '看見',
    '看见',
    'kànjiàn',
    'see; catch sight of',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    52,
    NULL,
    '塊',
    '块',
    'kuài',
    'lump; piece; sum of money',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    53,
    NULL,
    '來',
    '来',
    'lái',
    'come; arrive; ever since; next',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    54,
    NULL,
    '老師',
    '老师',
    'lǎoshī',
    'teacher',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    55,
    NULL,
    '了',
    '了',
    'le',
    'indicates a completed or finished action',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    56,
    NULL,
    '冷',
    '冷',
    'lěng',
    'cold',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    57,
    NULL,
    '裡',
    '里',
    'lǐ',
    'inside; Chinese mile (~.5 km)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    58,
    NULL,
    '六',
    '六',
    'liù',
    'six',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    59,
    NULL,
    '媽媽',
    '妈妈',
    'māma',
    'mom; mum',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    60,
    NULL,
    '嗎',
    '吗',
    'ma',
    'indicates a yes/no question (added to a statement)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    61,
    NULL,
    '買',
    '买',
    'mǎi',
    'to buy',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    62,
    NULL,
    '貓',
    '猫',
    'māo',
    'cat',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    63,
    NULL,
    '沒關系',
    '没关系',
    'méi guānxi',
    'it doesn\'t matter; never mind',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    64,
    NULL,
    '沒有',
    '没有',
    'méiyǒu',
    'not have; there is not',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    65,
    NULL,
    '米飯',
    '米饭',
    'mǐfàn',
    '(cooked) rice',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    66,
    NULL,
    '明天',
    '明天',
    'míngtiān',
    'tomorrow',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    67,
    NULL,
    '名字',
    '名字',
    'míngzi',
    'name',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    68,
    NULL,
    '哪',
    '哪',
    'nǎa',
    'which; how',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    69,
    NULL,
    '哪兒',
    '哪儿',
    'nǎr',
    'where? (Beijing accent)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    70,
    NULL,
    '那',
    '那',
    'nà',
    'that; then',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    71,
    NULL,
    '呢',
    '呢',
    'ne',
    'indicates a question; how about...?;',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    72,
    NULL,
    '能',
    '能',
    'néng',
    'can; be able',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    73,
    NULL,
    '你',
    '你',
    'nǐ',
    'you (singular)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    74,
    NULL,
    '年',
    '年',
    'nián',
    'year',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    75,
    NULL,
    '女兒',
    '女儿',
    'nǚ\'ér',
    'daughter',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    76,
    NULL,
    '朋友',
    '朋友',
    'péngyou',
    'friend',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    77,
    NULL,
    '漂亮',
    '漂亮',
    'piàoliang',
    'pretty; beautiful',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    78,
    NULL,
    '蘋果',
    '苹果',
    'píngguǒ',
    'apple',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    79,
    NULL,
    '七',
    '七',
    'qī',
    'seven',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    80,
    NULL,
    '錢',
    '钱',
    'qián',
    'money; coin',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    81,
    NULL,
    '前面',
    '前面',
    'qiánmiàn',
    'in front',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    82,
    NULL,
    '請',
    '请',
    'qǐng',
    'please; invite; to treat someone to something',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    83,
    NULL,
    '去',
    '去',
    'qù',
    'go; to leave',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    84,
    NULL,
    '熱',
    '热',
    'rè',
    'heat; hot',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    85,
    NULL,
    '人',
    '人',
    'rén',
    'person; man; people',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    86,
    NULL,
    '認識',
    '认识',
    'rènshi',
    'recognize; know (a person)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    87,
    NULL,
    '三',
    '三',
    'sān',
    'three',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    88,
    NULL,
    '商店',
    '商店',
    'shāngdiàn',
    'shop; store',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    89,
    NULL,
    '上',
    '上',
    'shàng',
    'above; up',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    90,
    NULL,
    '上午',
    '上午',
    'shàngwǔ',
    'late morning (before noon)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    91,
    NULL,
    '少',
    '少',
    'shǎo',
    'few; little',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    92,
    NULL,
    '誰',
    '谁',
    'shéi',
    'who',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    93,
    NULL,
    '什麼',
    '什么',
    'shénme',
    'what? (replaces the noun to turn a statement into a question)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    94,
    NULL,
    '十',
    '十',
    'shí',
    'ten',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    95,
    NULL,
    '時候',
    '时候',
    'shíhou',
    'time',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    96,
    NULL,
    '是',
    '是',
    'shì',
    'be; is; are; am',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    97,
    NULL,
    '書',
    '书',
    'shū',
    'book; letter',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    98,
    NULL,
    '水',
    '水',
    'shuǐ',
    'water',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    99,
    NULL,
    '水果',
    '水果',
    'shuǐguǒ',
    'fruit',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    100,
    NULL,
    '睡覺',
    '睡觉',
    'shuì jiào',
    'to sleep; go to bed',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    101,
    NULL,
    '說',
    '说',
    'shuō',
    'speak',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    102,
    NULL,
    '四',
    '四',
    'sì',
    'four',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    103,
    NULL,
    '歲',
    '岁',
    'suì',
    'years old; age',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    104,
    NULL,
    '他',
    '他',
    'tā',
    'he; him',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    105,
    NULL,
    '她',
    '她',
    'tā',
    'she',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    106,
    NULL,
    '太',
    '太',
    'tài',
    'too (much)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    107,
    NULL,
    '天氣',
    '天气',
    'tiānqì',
    'weather',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    108,
    NULL,
    '聽',
    '听',
    'tīng',
    'listen; hear',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    109,
    NULL,
    '同學',
    '同学',
    'tóngxué',
    'fellow student; schoolmate',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    110,
    NULL,
    '喂',
    '喂',
    'wèi',
    'hello (on the phone)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    111,
    NULL,
    '我',
    '我',
    'wǒ',
    'I; me',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    112,
    NULL,
    '我們',
    '我们',
    'wǒmen',
    'we; us',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    113,
    NULL,
    '五',
    '五',
    'wǔ',
    'five',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    114,
    NULL,
    '喜歡',
    '喜欢',
    'xǐhuan',
    'to like',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    115,
    NULL,
    '下',
    '下',
    'xià',
    'fall; below',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    116,
    NULL,
    '下午',
    '下午',
    'xiàwǔ',
    'afternoon',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    117,
    NULL,
    '下雨',
    '下雨',
    'xiàyǔ',
    'to rain',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    118,
    NULL,
    '先生',
    '先生',
    'xiānsheng',
    'Mr.; Sir',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    119,
    NULL,
    '現在',
    '现在',
    'xiànzài',
    'now',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    120,
    NULL,
    '想',
    '想',
    'xiǎng',
    'think; believe; suppose; would like to',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    121,
    NULL,
    '小',
    '小',
    'xiǎo',
    'small; young',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    122,
    NULL,
    '小姐',
    '小姐',
    'xiǎojie',
    'young lady; miss; Ms.',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    123,
    NULL,
    '些',
    '些',
    'xiē',
    'some; few; several',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    124,
    NULL,
    '寫',
    '写',
    'xiě',
    'to write; to compose',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    125,
    NULL,
    '謝謝',
    '谢谢',
    'xièxie',
    'thank you',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    126,
    NULL,
    '星期',
    '星期',
    'xīngqī',
    'week',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    127,
    NULL,
    '學生',
    '学生',
    'xuésheng',
    'student',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    128,
    NULL,
    '學習',
    '学习',
    'xuéxí',
    'learn; to study',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    129,
    NULL,
    '學校',
    '学校',
    'xuéxiào',
    'school',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    130,
    NULL,
    '一',
    '一',
    'yī',
    'one; once; a',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    131,
    NULL,
    '衣服',
    '衣服',
    'yīfu',
    'clothes',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    132,
    NULL,
    '醫生',
    '医生',
    'yīshēng',
    'doctor',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    133,
    NULL,
    '醫院',
    '医院',
    'yīyuàn',
    'hospital',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    134,
    NULL,
    '椅子',
    '椅子',
    'yǐzi',
    'chair',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    135,
    NULL,
    '一點兒',
    '一点儿',
    'yìdiǎnr',
    'a bit; a few',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    136,
    NULL,
    '有',
    '有',
    'yǒu',
    'have',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    137,
    NULL,
    '月',
    '月',
    'yuè',
    'moon; month',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    138,
    NULL,
    '在',
    '在',
    'zài',
    'at; on; in; indicates an action in progress',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    139,
    NULL,
    '再見',
    '再见',
    'zàijiàn',
    'goodbye; see you later',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    140,
    NULL,
    '怎麼',
    '怎么',
    'zěnme',
    'how?',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    141,
    NULL,
    '怎麼樣',
    '怎么样',
    'zěnmeyàng',
    'how about?; how is/was it?',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    142,
    NULL,
    '這',
    '这',
    'zhè',
    'this',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    143,
    NULL,
    '中國',
    '中国',
    'Zhōngguó',
    'China',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    144,
    NULL,
    '中午',
    '中午',
    'zhōngwǔ',
    'noon; midday',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    145,
    NULL,
    '住',
    '住',
    'zhù',
    'to live; reside; to stop',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    146,
    NULL,
    '桌子',
    '桌子',
    'zhuōzi',
    'table; desk',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    147,
    NULL,
    '字',
    '字',
    'zì',
    'letter; character',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    148,
    NULL,
    '昨天',
    '昨天',
    'zuótiān',
    'yesterday',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    149,
    NULL,
    '做',
    '做',
    'zuò',
    'do; make',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    150,
    NULL,
    '坐',
    '坐',
    'zuò',
    'sit',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    151,
    NULL,
    '吧',
    '吧',
    'ba',
    'particle indicating polite suggestion; | onomatopoeia | bar (serving drinks, providing internet access, etc.)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    152,
    NULL,
    '白',
    '白',
    'bái',
    'white; snowy; pure; bright; empty (Kangxi radical 106)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    153,
    NULL,
    '百',
    '百',
    'bǎi',
    'hundred',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    154,
    NULL,
    '幫助',
    '帮助',
    'bāngzhù',
    'help; assist; aid',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    155,
    NULL,
    '報紙',
    '报纸',
    'bàozhǐ',
    'newspaper',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    156,
    NULL,
    '比',
    '比',
    'bǐ',
    'compare; (indicates comparison) (Kangxi radical 81); to gesticulate as one talks',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    157,
    NULL,
    '別',
    '别',
    'bié',
    'don\'t do something; don\'t | depart; | other; difference; distinguish',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    158,
    NULL,
    '賓館',
    '宾馆',
    'bīnguǎn',
    'guesthouse; hotel',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    159,
    NULL,
    '長',
    '长',
    'cháng, zhǎng',
    'long; length | grow; chief (Kangxi radical 168)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    160,
    NULL,
    '唱歌',
    '唱歌',
    'chànggē',
    'sing (a song)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    161,
    NULL,
    '出',
    '出',
    'chū',
    'go out; occur',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    162,
    NULL,
    '穿',
    '穿',
    'chuān',
    'to wear; put on; penetrate',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    163,
    NULL,
    '次',
    '次',
    'cì',
    '(mw for number of times of occurrence); nth; order',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    164,
    NULL,
    '從',
    '从',
    'cóng',
    'from; obey; observe',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    165,
    NULL,
    '錯',
    '错',
    'cuò',
    'mistake; error; blunder; miss an opportunity',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    166,
    NULL,
    '打籃球',
    '打篮球',
    'dǎ lánqiú',
    'play basketball',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    167,
    NULL,
    '大家',
    '大家',
    'dàjiā',
    'everyone',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    168,
    NULL,
    '到',
    '到',
    'dào',
    'arrive (at a place); until (a time)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    169,
    NULL,
    '得',
    '得',
    'de',
    '(complement particle)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    170,
    NULL,
    '等',
    '等',
    'děng',
    'to wait; rank; equal; etc.',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    171,
    NULL,
    '弟弟',
    '弟弟',
    'dìdi',
    'younger brother',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    172,
    NULL,
    '第一',
    '第一',
    'dìyī',
    'first; number 1',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    173,
    NULL,
    '懂',
    '懂',
    'dǒng',
    'understand; know',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    174,
    NULL,
    '對',
    '对',
    'duì',
    'correct; a pair; to face; be opposite; to; towards',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    175,
    NULL,
    '房間',
    '房间',
    'fángjiān',
    'room',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    176,
    NULL,
    '非常',
    '非常',
    'fēicháng',
    'extremely; extraordinary; very',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    177,
    NULL,
    '服務員',
    '服务员',
    'fúwùyuán',
    'waiter/waitress; server; attendant',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    178,
    NULL,
    '高',
    '高',
    'gāo',
    'high; tall (Kangxi radical 189)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    179,
    NULL,
    '告訴',
    '告诉',
    'gàosu',
    'to tell; inform',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    180,
    NULL,
    '哥哥',
    '哥哥',
    'gēge',
    'older brother',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    181,
    NULL,
    '給',
    '给',
    'gěi',
    'to give; to grant; (passive particle)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    182,
    NULL,
    '公共汽車',
    '公共汽车',
    'gōnggòng qìchē',
    '(public) bus',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    183,
    NULL,
    '公司',
    '公司',
    'gōngsī',
    'company; corporation',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    184,
    NULL,
    '貴',
    '贵',
    'guì',
    'expensive; noble; honorable; Guizhou province (abbreviation)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    185,
    NULL,
    '過',
    '过',
    'guò',
    'to pass; to cross; go over; (indicates a past experience)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    186,
    NULL,
    '還',
    '还',
    'hái',
    'still; yet; in addition; even',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    187,
    NULL,
    '孩子',
    '孩子',
    'háizi',
    'child; children; son or daughter',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    188,
    NULL,
    '好吃',
    '好吃',
    'hǎochī',
    'tasty',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    189,
    NULL,
    '黑',
    '黑',
    'hēi',
    'black; dark (Kangxi radical 203); Heilongjiang province (abbreviation)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    190,
    NULL,
    '紅',
    '红',
    'hóng',
    'red; symbol of success; bonus; popular',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    191,
    NULL,
    '火車站',
    '火车站',
    'huǒchēzhàn',
    'train station',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    192,
    NULL,
    '機場',
    '机场',
    'jīchǎng',
    'airport; airfield',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    193,
    NULL,
    '雞蛋',
    '鸡蛋',
    'jīdàn',
    '(chicken) egg',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    194,
    NULL,
    '件',
    '件',
    'jiàn',
    '(mw for things, clothes, and items)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    195,
    NULL,
    '教室',
    '教室',
    'jiàoshì',
    'classroom',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    196,
    NULL,
    '姐姐',
    '姐姐',
    'jiějie',
    'older sister',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    197,
    NULL,
    '介紹',
    '介绍',
    'jièshào',
    'to introduce; recommend; introduction',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    198,
    NULL,
    '進',
    '进',
    'jìn',
    'enter; come in',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    199,
    NULL,
    '近',
    '近',
    'jìn',
    'near; close (to)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    200,
    NULL,
    '就',
    '就',
    'jiù',
    'then; at once; just; only; with regard to',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    201,
    NULL,
    '覺得',
    '觉得',
    'juéde',
    'feel; think',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    202,
    NULL,
    '咖啡',
    '咖啡',
    'kāfēi',
    'coffee',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    203,
    NULL,
    '開始',
    '开始',
    'kāishǐ',
    'begin; to start; beginning',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    204,
    NULL,
    '考試',
    '考试',
    'kǎoshì',
    'test; exam; to give or take a test',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    205,
    NULL,
    '可能',
    '可能',
    'kěnéng',
    'possible; maybe',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    206,
    NULL,
    '可以',
    '可以',
    'kěyǐ',
    'can; may; possible; okay',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    207,
    NULL,
    '課',
    '课',
    'kè',
    'class; subject; lesson; course',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    208,
    NULL,
    '快',
    '快',
    'kuài',
    'fast; quick; swift',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    209,
    NULL,
    '快樂',
    '快乐',
    'kuàilè',
    'happy',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    210,
    NULL,
    '累',
    '累',
    'lèi',
    'tired',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    211,
    NULL,
    '離',
    '离',
    'lí',
    'leave; depart; go away; apart from',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    212,
    NULL,
    '兩',
    '两',
    'liǎng',
    'two; 2; both; (unit of weight equal to 50 grams)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    213,
    NULL,
    '零',
    '零',
    'líng',
    'zero; remnant',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    214,
    NULL,
    '路',
    '路',
    'lù',
    'road; path; journey; route',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    215,
    NULL,
    '旅游',
    '旅游',
    'lǚyóu',
    'trip; journey; tour',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    216,
    NULL,
    '賣',
    '卖',
    'mài',
    'to sell',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    217,
    NULL,
    '慢',
    '慢',
    'màn',
    'slow',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    218,
    NULL,
    '忙',
    '忙',
    'máng',
    'busy',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    219,
    NULL,
    '每',
    '每',
    'měi',
    'each; every',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    220,
    NULL,
    '妹妹',
    '妹妹',
    'mèimei',
    'younger sister',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    221,
    NULL,
    '門',
    '门',
    'mén',
    'door; opening; gate (Kangxi radical 169)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    222,
    NULL,
    '面條',
    '面条',
    'miàntiáo',
    'noodles',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    223,
    NULL,
    '男',
    '男',
    'nán',
    'male',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    224,
    NULL,
    '您',
    '您',
    'nín',
    'you (polite)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    225,
    NULL,
    '牛奶',
    '牛奶',
    'niúnǎi',
    'cow\'s milk',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    226,
    NULL,
    '女',
    '女',
    'nǚ',
    'woman; female (Kangxi radical 38)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    227,
    NULL,
    '旁邊',
    '旁边',
    'pángbiān',
    'side, beside',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    228,
    NULL,
    '跑步',
    '跑步',
    'pǎobù',
    'to run; to jog',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    229,
    NULL,
    '便宜',
    '便宜',
    'piányi',
    'cheap',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    230,
    NULL,
    '票',
    '票',
    'piào',
    'ticket; bank note; a vote',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    231,
    NULL,
    '妻子',
    '妻子',
    'qīzi',
    'wife',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    232,
    NULL,
    '起床',
    '起床',
    'qǐ chuáng',
    'get out of bed',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    233,
    NULL,
    '千',
    '千',
    'qiān',
    'one thousand',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    234,
    NULL,
    '鉛筆',
    '铅笔',
    'qiānbǐ',
    'pencil',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    235,
    NULL,
    '晴',
    '晴',
    'qíng',
    'clear; fine (as of weather)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    236,
    NULL,
    '去年',
    '去年',
    'qùnián',
    'last year',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    237,
    NULL,
    '讓',
    '让',
    'ràng',
    'ask; let; yield',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    238,
    NULL,
    '日',
    '日',
    'rì',
    'sun; day; date; time (Kangxi radical 72)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    239,
    NULL,
    '上班',
    '上班',
    'shàngbān',
    'go to work; be on duty',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    240,
    NULL,
    '身體',
    '身体',
    'shēntǐ',
    'health; (human) body',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    241,
    NULL,
    '生病',
    '生病',
    'shēngbìng',
    'get sick; fall ill',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    242,
    NULL,
    '生日',
    '生日',
    'shēngrì',
    'birthday',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    243,
    NULL,
    '時間',
    '时间',
    'shíjiān',
    'time; period',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    244,
    NULL,
    '事情',
    '事情',
    'shìqing',
    'matter; affair; thing; business',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    245,
    NULL,
    '手表',
    '手表',
    'shǒubiǎo',
    'wristwatch',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    246,
    NULL,
    '手機',
    '手机',
    'shǒujī',
    'mobile (cell) phone',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    247,
    NULL,
    '說話',
    '说话',
    'shuōhuà',
    'to talk; speak',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    248,
    NULL,
    '送',
    '送',
    'sòng',
    'deliver; to carry; to give; send',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    249,
    NULL,
    '雖然',
    '虽然',
    'suīrán',
    'although; even though',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    250,
    NULL,
    '但是',
    '但是',
    'dànshì',
    'but; however',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    251,
    NULL,
    '它',
    '它',
    'tā',
    'it',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    252,
    NULL,
    '踢足球',
    '踢足球',
    'tīzúqiú',
    'to play football/soccer',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    253,
    NULL,
    '題',
    '题',
    'tí',
    'topic; subject; question on a test or assignment',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    254,
    NULL,
    '跳舞',
    '跳舞',
    'tiàowǔ',
    'to dance',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    255,
    NULL,
    '外',
    '外',
    'wài',
    'outer; outside; in addition; foreign',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    256,
    NULL,
    '完',
    '完',
    'wán',
    'to finish; be over; complete',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    257,
    NULL,
    '玩',
    '玩',
    'wán',
    'to play; have a good time; visit; enjoy',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    258,
    NULL,
    '晚上',
    '晚上',
    'wǎnshang',
    'evening; night',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    259,
    NULL,
    '往',
    '往',
    'wǎng',
    'to go (in a direction); towards; in the past',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    260,
    NULL,
    '為什麼',
    '为什么',
    'wèishénme',
    'why?; for what reason?',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    261,
    NULL,
    '問',
    '问',
    'wèn',
    'ask; inquire',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    262,
    NULL,
    '問題',
    '问题',
    'wèntí',
    'question; problem',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    263,
    NULL,
    '西瓜',
    '西瓜',
    'xīguā',
    'watermelon',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    264,
    NULL,
    '希望',
    '希望',
    'xīwàng',
    'to hope; wish for; to desire',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    265,
    NULL,
    '洗',
    '洗',
    'xǐ',
    'to wash; bathe',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    266,
    NULL,
    '小時',
    '小时',
    'xiǎoshí',
    'hour',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    267,
    NULL,
    '笑',
    '笑',
    'xiào',
    'to laugh; to smile',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    268,
    NULL,
    '新',
    '新',
    'xīn',
    'new; Xinjiang autonomous region (abbreviation)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    269,
    NULL,
    '姓',
    '姓',
    'xìng',
    'surname; family name',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    270,
    NULL,
    '休息',
    '休息',
    'xiūxi',
    'to rest; take a break',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    271,
    NULL,
    '雪',
    '雪',
    'xuě',
    'snow',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    272,
    NULL,
    '顏色',
    '颜色',
    'yánsè',
    'color',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    273,
    NULL,
    '眼睛',
    '眼睛',
    'yǎnjing',
    'eye',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    274,
    NULL,
    '羊肉',
    '羊肉',
    'yángròu',
    'mutton; lamb',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    275,
    NULL,
    '藥',
    '药',
    'yào',
    'medicine; drug; cure; chemical',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    276,
    NULL,
    '要',
    '要',
    'yào',
    'to want; to need; will/shall; important',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    277,
    NULL,
    '也',
    '也',
    'yě',
    'also; too',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    278,
    NULL,
    '一起',
    '一起',
    'yìqǐ',
    'together; in the same place',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    279,
    NULL,
    '一下',
    '一下',
    'yíxià',
    'a little bit/while; one time; once',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    280,
    NULL,
    '已經',
    '已经',
    'yǐjing',
    'already',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    281,
    NULL,
    '意思',
    '意思',
    'yìsi',
    'meaning; idea; opinion',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    282,
    NULL,
    '因為',
    '因为',
    'yīnwèi',
    'because',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    283,
    NULL,
    '所以',
    '所以',
    'suǒyǐ',
    'so; therefore; as a result',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    284,
    NULL,
    '陰',
    '阴',
    'yīn',
    'cloudy (weather); yin (the negative principle of Yin and Yang); secret; the moon; negative; shade',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    285,
    NULL,
    '游泳',
    '游泳',
    'yóuyǒng',
    'to swim',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    286,
    NULL,
    '右邊',
    '右边',
    'yòubian',
    'the right (as opposed to left) side',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    287,
    NULL,
    '魚',
    '鱼',
    'yú',
    'fish (Kangxi radical 195)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    288,
    NULL,
    '遠',
    '远',
    'yuǎn',
    'far; distant; remote',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    289,
    NULL,
    '運動',
    '运动',
    'yùndòng',
    '(physical) exercise; movement; sports; campaign',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    290,
    NULL,
    '再',
    '再',
    'zài',
    'again; once more',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    291,
    NULL,
    '早上',
    '早上',
    'zǎoshang',
    '(early) morning',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    292,
    NULL,
    '丈夫',
    '丈夫',
    'zhàngfu',
    'husband; man',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    293,
    NULL,
    '找',
    '找',
    'zhǎo',
    'try to find; look for; seek; to give change',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    294,
    NULL,
    '著',
    '着',
    'zhe',
    '-ing (indicating action in progress)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    295,
    NULL,
    '真',
    '真',
    'zhēn',
    'real; true; genuine',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    296,
    NULL,
    '正在',
    '正在',
    'zhèngzài',
    'in the process of (doing something); currently',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    297,
    NULL,
    '知道',
    '知道',
    'zhīdao',
    'know; be aware of',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    298,
    NULL,
    '准備',
    '准备',
    'zhǔnbèi',
    'prepare; get ready',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    299,
    NULL,
    '走',
    '走',
    'zǒu',
    'to walk; to go; to move (Kangxi radical 156)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    300,
    NULL,
    '最',
    '最',
    'zuì',
    'the most; -est; (indicator for superlative)',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );
INSERT INTO
  `Terms` (
    `id`,
    `lastStudied`,
    `side1`,
    `side2`,
    `side3`,
    `translation`,
    `partOfSpeech`,
    `notes`,
    `occurencesStudied`,
    `durationStudied`,
    `side1_correct`,
    `side2_correct`,
    `side3_correct`,
    `side1_unknown`,
    `side2_unknown`,
    `side3_unknown`,
    `side1_incorrect`,
    `side2_incorrect`,
    `side3_incorrect`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    301,
    NULL,
    '左邊',
    '左边',
    'zuǒbian',
    'the left side; the left',
    NULL,
    NULL,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    '2020-01-18 16:28:56',
    '2020-01-18 16:28:56'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: UserHistories
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: Users
# ------------------------------------------------------------


/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
